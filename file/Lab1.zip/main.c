/*
 * Lab1.c
 *
 * Created: 1/29/2019 08:14:49
 * Author : Ben L
 */

#define F_CPU 16000000

#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	DDRB = 0x0F; // Enable outputs
	uint16_t i = 0; // Iterator variable
  /* Replace with your application code */
  while (1)
  {
		for( i = 0; i < 16; i++){
			PORTB = i; // Copy i to output register
		}
  }
}
